For now, this project has just the base classes.
In a day or two the CLI will be done.
 Check back soon for basic GUI.
 (for now, vsbuild is Out of Order)

